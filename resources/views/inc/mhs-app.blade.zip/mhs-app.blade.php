<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>KOMETA IPB</title>

	<!-- Main Styles -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/styles/style.min.css')}}">
	
	<!-- Themify Icon -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/fonts/themify-icons/themify-icons.css')}}">

	<!-- mCustomScrollbar -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/mCustomScrollbar/jquery.mCustomScrollbar.min.css')}}">

	<!-- Waves Effect -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/waves/waves.min.css')}}">

	<!-- Sweet Alert -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/sweet-alert/sweetalert.css')}}">
	
	<!-- Jquery UI -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/jquery-ui/jquery-ui.min.css')}}">
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/jquery-ui/jquery-ui.structure.min.css')}}">
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/jquery-ui/jquery-ui.theme.min.css')}}">

	<!-- FullCalendar -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/fullcalendar/fullcalendar.min.css')}}">
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/fullcalendar/fullcalendar.print.css')}}" media='print'>

    <!-- Select2 -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/select2/css/select2.min.css')}}">

    <!-- Timepicker -->
	<link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/timepicker/bootstrap-timepicker.min.css')}}">

    <!-- Datepicker -->
    <link rel="stylesheet" href="{{asset('bootstrap-spacex/assets/plugin/datepicker/css/bootstrap-datepicker.min.css')}}">

</head>

<div class="fixed-navbar">
    <div class="pull-left">
        <button type="button" class="menu-mobile-button glyphicon glyphicon-menu-hamburger js__menu_mobile"></button>
        <h1 class="page-title"></h1>
        <!-- /.page-title -->
    </div>
    <!-- /.pull-left -->
    <div class="pull-right">
        <div class="ico-item">
            {{ Carbon\Carbon::today()->format('D, d F Y')}} <span id='txt'></span>
        </div>
        <div class="ico-item">
            <a href="#" class="ico-item ti-search js__toggle_open" data-target="#searchform-header"></a>
            <form action="#" id="searchform-header" class="searchform js__toggle"><input type="search" placeholder="Search..." class="input-search"><button class="ti-search button-search" type="submit"></button></form>
            <!-- /.searchform -->
        </div>
        <!-- /.ico-item -->
        <div class="ico-item">
            <i class="ti-user"></i>
            <ul class="sub-ico-item">
                <li><a href="#">Settings</a></li>
                <li>
                    <a class="dropdown-item" href="{{ route('logout') }}"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        {{ __('Logout') }}
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                </li>
            </ul>
            <!-- /.sub-ico-item -->
        </div>
    </div>
    <!-- /.pull-right -->
</div>
<!-- /.fixed-navbar -->

<div class="main-menu">
    <header class="header">
        <a href="/home" class="logo"><i class="ico fa fa-laptop"></i>KOMETA IPB</a>
        <button type="button" class="button-close fa fa-times js__menu_close"></button>
    </header>
    <!-- /.header -->
    <div class="content">

        <div class="navigation">

            <div class="card-content">
                <ul class="notice-list">
                    <li>
                        <a href="#">
                            @if($usr->image != NULL)
                            <span class="avatar"><img src="https://simak.ipb.ac.id{{$usr->image}}" alt=""></span>
                            @else
                            <span class="avatar"><img src="{{asset('img/user.png')}}" alt=""></span>
                            @endif
                            <span class="desc" style="color: black"><strong>{{$usr->Nama}}</strong></span>
                            <span class="desc">{{$usr->NIM}}</span>
                        </a>
                    </li>
                </ul>
            </div>

            <!-- <h5 class="title">Navigation</h5> -->

            <!-- /.title -->
            <ul class="menu js__accordion">
                <li class="{{ (\Request::route()->getName() == 'mhs-index') ? 'current' : '' }}">
                    <a class="waves-effect" href="{{route('mhs-index')}}"><i class="menu-icon fa fa-home"></i><span>Beranda</span></a>
                </li>

                <!-- check drop down -->
                <li class="{{ (\Request::route()->getName() == 'mhs-pkl') ? 'current' : '' }}">
                    <a class="waves-effect parent-item js__control" href="#"><i class="menu-icon fa fa-map-pin"></i><span>PKL</span><span class="menu-arrow fa fa-angle-down"></span></a>
                    <ul class="sub-menu js__content">
                        <li><a href="{{route('mhs-pkl-surat')}}"><i class="fa fa-circle-o"></i> Surat Pengantar</a></li>
                        <li><a href="{{route('mhs-pkl-berkas')}}"><i class="fa fa-circle-o"></i> Berkas Pelaksanaan</a></li>
                        <li><a href="{{route('mhs-pkl-instansi')}}"><i class="fa fa-circle-o"></i> Identitas Instansi</a></li>
                    </ul>
                </li>
                <!-- end check drop down -->
                <li class="{{ (\Request::route()->getName() == 'mhs-bimbingan') ? 'current' : '' }}">
                    <a class="waves-effect" href="{{route('mhs-bimbingan')}}"><i class="menu-icon fa fa-thumb-tack"></i><span>Bimbingan</span></a>
                </li> 
                <li class="{{ (\Request::route()->getName() == 'mhs-kolokium') ? 'current' : '' }}">
                    <a class="waves-effect" href="{{route('mhs-kolokium')}}"><i class="menu-icon fa fa-user"></i><span>Kolokium</span></a>
                </li>
                <li class="{{ (\Request::route()->getName() == 'mhs-seminar') ? 'current' : '' }}">
                    <a class="waves-effect" href="{{route('mhs-seminar')}}"><i class="menu-icon fa fa-users"></i><span>Seminar</span></a>
                </li>
                <li class="{{ (\Request::route()->getName() == 'mhs-skripsi') ? 'current' : '' }}">
                    <a class="waves-effect" href="{{route('mhs-skripsi')}}"><i class="menu-icon fa fa-graduation-cap"></i><span>Skripsi</span></a>
                </li>

                
            </ul>
        </div>
        <!-- /.navigation -->
    </div>
    <!-- /.content -->
</div>
<!-- /.main-menu -->

<body onload="startTime()">

    @yield('content')

    <!-- Modal Konfirmasi Semua Form -->
        <div class="modal fade" id="modal-konfirmasi-form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <h4>Apakah form sudah diisi dengan benar?</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-sm waves-effect waves-light" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success btn-sm waves-effect waves-light">Ya</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    @if($pkl['statusSurat'] !== NULL)
    <!-- Modal Batal Surat -->
    <div class="modal fade" id="modal-tolak-surat" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4>Apakah Anda yakin ingin membatalkan form?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm waves-effect waves-light" data-dismiss="modal">Tidak</button>
                    <a href='{{"/mhs-pkl-surat-pengantar/tolak/".$pkl->id}}' type="button" class="btn btn-danger btn-sm waves-effect waves-light">Ya</a>
                </div>
            </div>
        </div>
    </div>
    @endif
    
    @if($pkl['statusBerkas'] !== NULL)
    <!-- Modal Batal Berkas -->
    <div class="modal fade" id="modal-tolak-berkas" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4>Apakah Anda yakin ingin membatalkan form?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm waves-effect waves-light" data-dismiss="modal">Tidak</button>
                    <a href='{{"/mhs-pkl-berkas-pelaksanaan/tolak/".$pkl->id}}' type="button" class="btn btn-danger btn-sm waves-effect waves-light">Ya</a>
                </div>
            </div>
        </div>
    </div>
    @endif

    @if($pkl['statusIns'] !== NULL)
    <!-- Modal Batal Instansi -->
    <div class="modal fade" id="modal-tolak-instansi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4>Apakah Anda yakin ingin membatalkan form?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm waves-effect waves-light" data-dismiss="modal">Tidak</button>
                    <a href='{{"/mhs-pkl-identitas-instansi/tolak/".$pkl->id}}' type="button" class="btn btn-danger btn-sm waves-effect waves-light">Ya</a>
                </div>
            </div>
        </div>
    </div>
    @endif

    @if($pembimbing['statusPembimbing'] !== NULL)
    <!-- Modal Batal Bimbingan -->
    <div class="modal fade" id="modal-tolak-pembimbing" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4>Apakah Anda yakin ingin membatalkan form?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm waves-effect waves-light" data-dismiss="modal">Tidak</button>
                    <a href='{{"/mhs-bimbingan/tolak/".$pembimbing->id}}' type="button" class="btn btn-danger btn-sm waves-effect waves-light">Ya</a>
                </div>
            </div>
        </div>
    </div>
    @endif

    @if($kolokium['statusKolokium'] !== NULL)
    <!-- Modal Batal Kolokium -->
    <div class="modal fade" id="modal-tolak-kolokium" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4>Apakah Anda yakin ingin membatalkan form?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm waves-effect waves-light" data-dismiss="modal">Tidak</button>
                    <a href='{{"/mhs-kolokium/tolak/".$kolokium->id}}' type="button" class="btn btn-danger btn-sm waves-effect waves-light">Ya</a>
                </div>
            </div>
        </div>
    </div>
    @endif

    @if($seminar['statusSeminar'] !== NULL)
    <!-- Modal Batal Seminar -->
    <div class="modal fade" id="modal-tolak-seminar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4>Apakah Anda yakin ingin membatalkan form?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm waves-effect waves-light" data-dismiss="modal">Tidak</button>
                    <a href='{{"/mhs-seminar/tolak/".$seminar->id}}' type="button" class="btn btn-danger btn-sm waves-effect waves-light">Ya</a>
                </div>
            </div>
        </div>
    </div>
    @endif

    @if($skripsi['statusSkripsi'] !== NULL)
    <!-- Modal Batal Skripsi -->
    <div class="modal fade" id="modal-tolak-skripsi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4>Apakah Anda yakin ingin membatalkan form?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-sm waves-effect waves-light" data-dismiss="modal">Tidak</button>
                    <a href='{{"/mhs-skripsi/tolak/".$skripsi->id}}' type="button" class="btn btn-danger btn-sm waves-effect waves-light">Ya</a>
                </div>
            </div>
        </div>
    </div>
    @endif
                            
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
		<script src="{{asset('bootstrap-spacex/assets/script/html5shiv.min.js')}}"></script>
		<script src="{{asset('bootstrap-spacex/assets/script/respond.min.js')}}"></script>
	<![endif]-->
	<!-- 
	================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="{{asset('bootstrap-spacex/assets/scripts/jquery.min.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/scripts/modernizr.min.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/plugin/bootstrap/js/bootstrap.min.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/plugin/mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/plugin/nprogress/nprogress.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/plugin/sweet-alert/sweetalert.min.js')}}"></script>
    <script src="{{asset('bootstrap-spacex/assets/plugin/waves/waves.min.js')}}"></script>
    <script src="{{asset('bootstrap-spacex/assets/scripts/sweetalert.init.min.js')}}"></script>
    
	<!-- Sparkline Chart -->
	<script src="{{asset('bootstrap-spacex/assets/plugin/chart/sparkline/jquery.sparkline.min.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/scripts/chart.sparkline.init.min.js')}}"></script>

	<!-- Jquery UI -->
	<script src="{{asset('bootstrap-spacex/assets/plugin/jquery-ui/jquery-ui.min.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/plugin/jquery-ui/jquery.ui.touch-punch.min.js')}}"></script>

	<!-- FullCalendar -->
	<script src="{{asset('bootstrap-spacex/assets/plugin/moment/moment.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/plugin/fullcalendar/fullcalendar.min.js')}}"></script>
	<script src="{{asset('bootstrap-spacex/assets/scripts/fullcalendar.init.js')}}"></script>
    
    <!-- Select2 -->
	<script src="{{asset('bootstrap-spacex/assets/plugin/select2/js/select2.min.js')}}"></script>
    
    <!-- Timepicker -->
    <script src="{{asset('bootstrap-spacex/assets/plugin/timepicker/bootstrap-timepicker.min.js')}}"></script>

    <!-- Datepicker -->
    <script src="{{asset('bootstrap-spacex/assets/plugin/datepicker/js/bootstrap-datepicker.min.js')}}"></script>

    <!-- Demo Scripts -->
    <script src="{{asset('bootstrap-spacex/assets/scripts/form.demo.min.js')}}"></script>
    <script src="{{asset('bootstrap-spacex/assets/scripts/main.min.js')}}"></script>
    
    <script>
        function startTime() {
        var today = new Date();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        m = checkTime(m);
        s = checkTime(s);
        document.getElementById('txt').innerHTML =
        h + ":" + m + ":" + s;
        var t = setTimeout(startTime, 500);
        }
        function checkTime(i) {
            if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
            return i;
        }
    </script>
</body>
</html>