/**
 * Theme: Ninja Admin Template
 * Author: NinjaTeam
 * Module/App: RWD Table Demo
 */

(function($) {
	"use strict";

	$('.table-responsive').responsiveTable();

})(jQuery);